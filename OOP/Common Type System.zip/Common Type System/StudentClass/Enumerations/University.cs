﻿namespace StudentClass.Enumerations
{
    public enum University
    {
        Oxford, KingsCollege, Harvard
    }
}
