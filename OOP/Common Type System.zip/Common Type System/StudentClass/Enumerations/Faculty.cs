﻿namespace StudentClass.Enumerations
{
    public enum Faculty
    {
        Phylosophy, Informatics, Economics
    }
}
