﻿namespace StudentClass.Enumerations
{
    public enum Speciality
    {
        Philosophy, Management, SoftwareEngineering
    }
}
